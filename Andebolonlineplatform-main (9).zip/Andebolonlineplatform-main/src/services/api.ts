import { 
  PlayDisplay, 
  TipDisplay, 
  TeamStatsDisplay, 
  AthleteStatsDisplay, 
  CommentDisplay, 
  User 
} from '../types';

// Simulate API delay
const delay = (ms: number = 300) => new Promise(resolve => setTimeout(resolve, ms));

// LocalStorage keys
const STORAGE_KEYS = {
  USERS: 'handball_users',
  PLAYS: 'handball_plays',
  TIPS: 'handball_tips',
  TEAM_STATS: 'handball_team_stats',
  ATHLETE_STATS: 'handball_athlete_stats',
  CURRENT_USER: 'handball_current_user'
};

// Generic storage functions
function getFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, data: T): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// Auth API
export const authAPI = {
  async login(email: string, password: string): Promise<User> {
    await delay();
    const users = getFromStorage<User[]>(STORAGE_KEYS.USERS, []);
    const user = users.find(u => u.email === email);
    
    if (!user) {
      throw new Error('Utilizador não encontrado');
    }
    
    saveToStorage(STORAGE_KEYS.CURRENT_USER, user);
    return user;
  },

  async register(userData: Omit<User, 'id'>): Promise<User> {
    await delay();
    const users = getFromStorage<User[]>(STORAGE_KEYS.USERS, []);
    
    if (users.some(u => u.email === userData.email)) {
      throw new Error('Email já registado');
    }
    
    const newUser: User = {
      ...userData,
      id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
    
    users.push(newUser);
    saveToStorage(STORAGE_KEYS.USERS, users);
    saveToStorage(STORAGE_KEYS.CURRENT_USER, newUser);
    
    return newUser;
  },

  async logout(): Promise<void> {
    await delay(100);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  },

  getCurrentUser(): User | null {
    return getFromStorage<User | null>(STORAGE_KEYS.CURRENT_USER, null);
  }
};

// Plays API
export const playsAPI = {
  async getAll(): Promise<PlayDisplay[]> {
    await delay();
    const plays = getFromStorage<PlayDisplay[]>(STORAGE_KEYS.PLAYS, []);
    // Convert date strings back to Date objects
    return plays.map(play => ({
      ...play,
      createdAt: new Date(play.createdAt),
      comments: play.comments?.map(c => ({
        ...c,
        createdAt: new Date(c.createdAt)
      })) || []
    }));
  },

  async getById(id: string): Promise<PlayDisplay | null> {
    await delay();
    const plays = await this.getAll();
    return plays.find(p => p.id === id) || null;
  },

  async create(playData: Omit<PlayDisplay, 'id' | 'createdAt' | 'comments'>): Promise<PlayDisplay> {
    await delay();
    const plays = await this.getAll();
    
    const newPlay: PlayDisplay = {
      ...playData,
      id: `play_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
      comments: []
    };
    
    plays.unshift(newPlay);
    saveToStorage(STORAGE_KEYS.PLAYS, plays);
    
    return newPlay;
  },

  async update(id: string, updates: Partial<PlayDisplay>): Promise<PlayDisplay> {
    await delay();
    const plays = await this.getAll();
    const index = plays.findIndex(p => p.id === id);
    
    if (index === -1) {
      throw new Error('Jogada não encontrada');
    }
    
    plays[index] = { ...plays[index], ...updates };
    saveToStorage(STORAGE_KEYS.PLAYS, plays);
    
    return plays[index];
  },

  async delete(id: string): Promise<void> {
    await delay();
    const plays = await this.getAll();
    const filtered = plays.filter(p => p.id !== id);
    saveToStorage(STORAGE_KEYS.PLAYS, filtered);
  },

  async addComment(playId: string, comment: Omit<CommentDisplay, 'id' | 'createdAt'>): Promise<CommentDisplay> {
    await delay();
    const plays = await this.getAll();
    const play = plays.find(p => p.id === playId);
    
    if (!play) {
      throw new Error('Jogada não encontrada');
    }
    
    const newComment: CommentDisplay = {
      ...comment,
      id: `comment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date()
    };
    
    if (!play.comments) {
      play.comments = [];
    }
    play.comments.push(newComment);
    saveToStorage(STORAGE_KEYS.PLAYS, plays);
    
    return newComment;
  }
};

// Tips API
export const tipsAPI = {
  async getAll(): Promise<TipDisplay[]> {
    await delay();
    const tips = getFromStorage<TipDisplay[]>(STORAGE_KEYS.TIPS, []);
    return tips.map(tip => ({
      ...tip,
      createdAt: new Date(tip.createdAt)
    }));
  },

  async getByCategory(category: string): Promise<TipDisplay[]> {
    await delay();
    const tips = await this.getAll();
    return category === 'all' ? tips : tips.filter(t => t.category === category);
  },

  async create(tipData: Omit<TipDisplay, 'id' | 'createdAt'>): Promise<TipDisplay> {
    await delay();
    const tips = await this.getAll();
    
    const newTip: TipDisplay = {
      ...tipData,
      id: `tip_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date()
    };
    
    tips.unshift(newTip);
    saveToStorage(STORAGE_KEYS.TIPS, tips);
    
    return newTip;
  },

  async update(id: string, updates: Partial<TipDisplay>): Promise<TipDisplay> {
    await delay();
    const tips = await this.getAll();
    const index = tips.findIndex(t => t.id === id);
    
    if (index === -1) {
      throw new Error('Dica não encontrada');
    }
    
    tips[index] = { ...tips[index], ...updates };
    saveToStorage(STORAGE_KEYS.TIPS, tips);
    
    return tips[index];
  },

  async delete(id: string): Promise<void> {
    await delay();
    const tips = await this.getAll();
    const filtered = tips.filter(t => t.id !== id);
    saveToStorage(STORAGE_KEYS.TIPS, filtered);
  }
};

// Team Stats API
export const teamStatsAPI = {
  async getAll(): Promise<TeamStatsDisplay[]> {
    await delay();
    return getFromStorage<TeamStatsDisplay[]>(STORAGE_KEYS.TEAM_STATS, []);
  },

  async getByDivision(division: string): Promise<TeamStatsDisplay[]> {
    await delay();
    const stats = await this.getAll();
    return stats.filter(s => s.division === division);
  },

  async getByTeam(teamName: string): Promise<TeamStatsDisplay[]> {
    await delay();
    const stats = await this.getAll();
    return stats.filter(s => s.teamName === teamName);
  }
};

// Athlete Stats API
export const athleteStatsAPI = {
  async getAll(): Promise<AthleteStatsDisplay[]> {
    await delay();
    return getFromStorage<AthleteStatsDisplay[]>(STORAGE_KEYS.ATHLETE_STATS, []);
  },

  async getByDivision(division: string): Promise<AthleteStatsDisplay[]> {
    await delay();
    const stats = await this.getAll();
    return stats.filter(s => s.division === division);
  },

  async getByTeam(team: string): Promise<AthleteStatsDisplay[]> {
    await delay();
    const stats = await this.getAll();
    return stats.filter(s => s.team === team);
  },

  async getByName(name: string): Promise<AthleteStatsDisplay | null> {
    await delay();
    const stats = await this.getAll();
    return stats.find(s => s.name === name) || null;
  }
};

// Initialize default data
export const initializeData = () => {
  // Only initialize if no data exists
  if (!localStorage.getItem(STORAGE_KEYS.PLAYS)) {
    const { mockPlays, mockTips, mockTeamStats, mockAthleteStats } = require('../data/mockData');
    saveToStorage(STORAGE_KEYS.PLAYS, mockPlays);
    saveToStorage(STORAGE_KEYS.TIPS, mockTips);
    saveToStorage(STORAGE_KEYS.TEAM_STATS, mockTeamStats);
    saveToStorage(STORAGE_KEYS.ATHLETE_STATS, mockAthleteStats);
  }
};
