import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, PlayDisplay, TipDisplay, TeamStatsDisplay, AthleteStatsDisplay } from '../types';
import { authAPI, playsAPI, tipsAPI, teamStatsAPI, athleteStatsAPI, initializeData } from '../services/api';

interface AppContextType {
  // Auth
  user: User | null;
  loading: boolean;
  
  // Data
  plays: PlayDisplay[];
  tips: TipDisplay[];
  teamStats: TeamStatsDisplay[];
  athleteStats: AthleteStatsDisplay[];
  
  // Loading states
  playsLoading: boolean;
  tipsLoading: boolean;
  statsLoading: boolean;
  
  // Actions
  login: (email: string, password: string) => Promise<void>;
  register: (userData: Omit<User, 'id'>) => Promise<void>;
  logout: () => Promise<void>;
  
  // Data refresh
  refreshPlays: () => Promise<void>;
  refreshTips: () => Promise<void>;
  refreshStats: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [plays, setPlays] = useState<PlayDisplay[]>([]);
  const [tips, setTips] = useState<TipDisplay[]>([]);
  const [teamStats, setTeamStats] = useState<TeamStatsDisplay[]>([]);
  const [athleteStats, setAthleteStats] = useState<AthleteStatsDisplay[]>([]);
  
  const [playsLoading, setPlaysLoading] = useState(false);
  const [tipsLoading, setTipsLoading] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);

  // Initialize data and check for current user
  useEffect(() => {
    const initialize = async () => {
      initializeData();
      const currentUser = authAPI.getCurrentUser();
      setUser(currentUser);
      
      if (currentUser) {
        await Promise.all([
          refreshPlays(),
          refreshTips(),
          refreshStats()
        ]);
      }
      
      setLoading(false);
    };
    
    initialize();
  }, []);

  const login = async (email: string, password: string) => {
    const loggedUser = await authAPI.login(email, password);
    setUser(loggedUser);
    
    // Load data after login
    await Promise.all([
      refreshPlays(),
      refreshTips(),
      refreshStats()
    ]);
  };

  const register = async (userData: Omit<User, 'id'>) => {
    const newUser = await authAPI.register(userData);
    setUser(newUser);
    
    // Load data after registration
    await Promise.all([
      refreshPlays(),
      refreshTips(),
      refreshStats()
    ]);
  };

  const logout = async () => {
    await authAPI.logout();
    setUser(null);
    setPlays([]);
    setTips([]);
    setTeamStats([]);
    setAthleteStats([]);
  };

  const refreshPlays = async () => {
    setPlaysLoading(true);
    try {
      const data = await playsAPI.getAll();
      setPlays(data);
    } finally {
      setPlaysLoading(false);
    }
  };

  const refreshTips = async () => {
    setTipsLoading(true);
    try {
      const data = await tipsAPI.getAll();
      setTips(data);
    } finally {
      setTipsLoading(false);
    }
  };

  const refreshStats = async () => {
    setStatsLoading(true);
    try {
      const [teams, athletes] = await Promise.all([
        teamStatsAPI.getAll(),
        athleteStatsAPI.getAll()
      ]);
      setTeamStats(teams);
      setAthleteStats(athletes);
    } finally {
      setStatsLoading(false);
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        loading,
        plays,
        tips,
        teamStats,
        athleteStats,
        playsLoading,
        tipsLoading,
        statsLoading,
        login,
        register,
        logout,
        refreshPlays,
        refreshTips,
        refreshStats
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
