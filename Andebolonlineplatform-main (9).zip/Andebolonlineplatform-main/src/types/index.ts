export type UserType = 'athlete' | 'coach' | null;

// Tabela: users
export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  type: UserType;
  team?: string;
}

// Tabela: épocas
export interface Season {
  id: string;
  data_inicio: Date;
  data_fim: Date;
}

// Tabela: equipas
export interface Team {
  id: string;
  nome: string;
  escalao_id?: string;
}

// Tabela: equipas_escalão
export interface TeamDivision {
  id: string;
  equipa_id: string;
  escalao: 'seniores' | 'sub-20' | 'sub-18' | 'sub-16' | 'sub-14';
}

// Tabela: atletas
export interface Athlete {
  id: string;
  user_id: string;
  equipa_id: string;
  epoca_id: string;
  posicao: 'pivot' | 'ponta' | 'lateral' | 'central' | 'guarda-redes';
  numero?: number;
}

// Tabela: treinadores
export interface Coach {
  id: string;
  user_id: string;
  equipa_id: string;
  epoca_id: string;
}

// Tabela: jogadas
export interface Play {
  id: string;
  user_id: string;
  titulo: string;
  descricao: string;
  ficheiro: string;
  data_upload: Date;
  // Campos derivados para exibição
  authorName?: string;
  authorType?: 'athlete' | 'coach';
  team?: string;
  category?: string;
  comments?: Comment[];
}

// Tabela: comentários
export interface Comment {
  id: string;
  user_id: string;
  jogada_id: string;
  texto: string;
  data: Date;
  // Campos derivados para exibição
  authorName?: string;
  authorType?: 'athlete' | 'coach';
}

// Tabela: dicas
export interface Tip {
  id: string;
  id_user_ef: string;
  titulo: string;
  conteudo: string;
  ficheiro?: string;
  data_upload: Date;
  // Campos derivados para exibição
  category?: 'finta' | 'drible' | 'remate' | 'defesa' | 'táctica';
  description?: string;
  authorName?: string;
  authorType?: 'athlete' | 'coach';
}

// Tabela: estatísticas_equipas
export interface TeamStats {
  id: string;
  equipa_id: string;
  epoca_id: string;
  escalao: 'seniores' | 'sub-20' | 'sub-18' | 'sub-16' | 'sub-14';
  // Campos derivados/calculados
  teamName?: string;
  division?: 'seniores' | 'sub-20' | 'sub-18' | 'sub-16' | 'sub-14';
  goalsScored?: number;
  goalsConceded?: number;
  matchesPlayed?: number;
  wins?: number;
  draws?: number;
  losses?: number;
}

// Tabela: estatísticas_atleta
export interface AthleteStats {
  id: string;
  atleta_id: string;
  golos_marcados: number;
  epoca: string;
  media_golos: number;
  // Campos adicionais necessários
  assists?: number;
  yellowCards?: number;
  redCards?: number;
  matchesPlayed?: number;
  // Campos derivados para exibição
  name?: string;
  team?: string;
  position?: 'pivot' | 'ponta' | 'lateral' | 'central' | 'guarda-redes';
  division?: 'seniores' | 'sub-20' | 'sub-18' | 'sub-16' | 'sub-14';
}

// Interface para exibição (compatibilidade com código existente)
export interface PlayDisplay {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  authorId: string;
  authorName: string;
  authorType: 'athlete' | 'coach';
  team: string;
  category: string;
  createdAt: Date;
  comments: CommentDisplay[];
}

export interface CommentDisplay {
  id: string;
  playId: string;
  authorId: string;
  authorName: string;
  authorType: 'athlete' | 'coach';
  content: string;
  createdAt: Date;
}

export interface TipDisplay {
  id: string;
  title: string;
  description: string;
  category: 'finta' | 'drible' | 'remate' | 'defesa' | 'táctica';
  content: string;
  authorId: string;
  authorName: string;
  authorType: 'athlete' | 'coach';
  createdAt: Date;
}

export interface TeamStatsDisplay {
  id: string;
  teamName: string;
  division: 'seniores' | 'sub-20' | 'sub-18' | 'sub-16' | 'sub-14';
  goalsScored: number;
  goalsConceded: number;
  matchesPlayed: number;
  wins: number;
  draws: number;
  losses: number;
}

export interface AthleteStatsDisplay {
  id: string;
  name: string;
  team: string;
  position: 'pivot' | 'ponta' | 'lateral' | 'central' | 'guarda-redes';
  division: 'seniores' | 'sub-20' | 'sub-18' | 'sub-16' | 'sub-14';
  goalsScored: number;
  matchesPlayed: number;
  assists: number;
  yellowCards: number;
  redCards: number;
}
