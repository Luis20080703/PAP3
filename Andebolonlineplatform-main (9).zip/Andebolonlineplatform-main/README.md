
  # Andebol Online Platform

  This is a code bundle for Andebol Online Platform. The original project is available at https://www.figma.com/design/h9gjx88jhdWy1PYGHvdfMF/Andebol-Online-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  